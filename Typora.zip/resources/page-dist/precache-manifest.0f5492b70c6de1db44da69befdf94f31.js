self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f1ee720fad600a26802be9682de4b9c1",
    "url": "./index.html"
  },
  {
    "revision": "c0256457b1ed517a7af0",
    "url": "./static/css/LicenseIndex.180dd4c7.ec3a4e5c.chunk.css"
  },
  {
    "revision": "6cb4467c153d0999b9de",
    "url": "./static/css/Preferences.962926a4.2f76d1bd.chunk.css"
  },
  {
    "revision": "c1a2e09fb0e36b41651a",
    "url": "./static/css/WelcomeIndex.63db304f.4f0cae51.chunk.css"
  },
  {
    "revision": "404fdc131151dc246fef",
    "url": "./static/css/localSettingIndex.a2c75cbd.4722268f.chunk.css"
  },
  {
    "revision": "5e44aa81854e28bd9129",
    "url": "./static/js/0.5cb8f524.chunk.js"
  },
  {
    "revision": "8b32dc95a2ee91e1b5d7d27e55fe304c",
    "url": "./static/js/0.5cb8f524.chunk.js.LICENSE.txt"
  },
  {
    "revision": "72760e1bb12c4d6668e7",
    "url": "./static/js/1.7816d24a.chunk.js"
  },
  {
    "revision": "634ed6f24f16a3a1315c",
    "url": "./static/js/12.45ac24ef.chunk.js"
  },
  {
    "revision": "5735008847451525374b1f222e4ab316",
    "url": "./static/js/12.45ac24ef.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c0256457b1ed517a7af0",
    "url": "./static/js/LicenseIndex.180dd4c7.b624d6a9.chunk.js"
  },
  {
    "revision": "6cb4467c153d0999b9de",
    "url": "./static/js/Preferences.962926a4.9420e568.chunk.js"
  },
  {
    "revision": "c1a2e09fb0e36b41651a",
    "url": "./static/js/WelcomeIndex.63db304f.0f2106b8.chunk.js"
  },
  {
    "revision": "404fdc131151dc246fef",
    "url": "./static/js/localSettingIndex.a2c75cbd.1ac24c45.chunk.js"
  },
  {
    "revision": "ea0cdf525dc17ab2d173",
    "url": "./static/js/main.ff8bdafd.chunk.js"
  },
  {
    "revision": "32af8fee8c88440a3a0c",
    "url": "./static/js/runtime-LicenseIndex.180dd4c7.f7c007dd.js"
  },
  {
    "revision": "31eade27ad84fcd5e43c",
    "url": "./static/js/runtime-Preferences.962926a4.285eabb5.js"
  },
  {
    "revision": "68fdb37641c2c95f87f3",
    "url": "./static/js/runtime-WelcomeIndex.63db304f.ab2b23b4.js"
  },
  {
    "revision": "02c80b5dbf4b0857413b",
    "url": "./static/js/runtime-localSettingIndex.a2c75cbd.6f0fb930.js"
  },
  {
    "revision": "a58e29c10aa59053062a",
    "url": "./static/js/runtime-main.97d0b459.js"
  },
  {
    "revision": "06a6aa233c23b10f45b5ec4a8924866b",
    "url": "./static/media/icon.06a6aa23.png"
  },
  {
    "revision": "1382c29cdb72f6c99043675d6e13b625",
    "url": "./static/media/photon-entypo.1382c29c.ttf"
  },
  {
    "revision": "2614e058b2dcb9d6e2e964730d795540",
    "url": "./static/media/photon-entypo.2614e058.eot"
  },
  {
    "revision": "bf614256dbc49f4bf2cf786706bb0712",
    "url": "./static/media/photon-entypo.bf614256.woff"
  }
]);